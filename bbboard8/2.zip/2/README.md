
# PHPIB 

This project is a simple discussion board built using PHP 8.4.1 and SQLite. It allows users to create posts, upload images, and reply to existing posts in a threaded manner. The project is organized across several files: `index.php`, `reply.php`, `style.css`, and a database (`database.db`). This README will guide you through the features, setup, and structure of the project.

## Features
- **Create Posts**: Users can create new posts with a name, text, and an optional image.
- **Threaded Replies**: Users can reply to an existing post, and those replies are displayed under the original post.
- **Image Uploads**: Supports uploading images in JPG, JPEG, PNG, and GIF formats.
- **Pagination**: Posts are displayed with pagination to manage viewing large numbers of posts.
- **Input Validation and Error Handling**: Basic input validation is in place to limit the size of names, text, and prevent security issues.
- **Responsive Design**: The UI is designed to work well on both desktop and mobile devices.

## File Structure
### 1. `index.php`
This file serves as the main page of the discussion board. It allows users to create new posts and view existing ones.
- **Database Initialization**: Creates or opens an SQLite3 database (`database.db`) and initializes a table (`posts`) if it doesn't already exist.
- **Form Submission Handling**: Handles form submissions to create new posts, with input sanitization for security.
- **Post Display**: Fetches posts from the database, along with replies count for each post. Posts are paginated with a default of 10 posts per page.
- **HTML Form**: Provides an HTML form for users to submit new posts with an optional image.

### 2. `reply.php`
This file handles viewing and replying to individual posts.
- **Original Post Display**: Loads the original post based on a `post_id` parameter passed in the URL.
- **Reply Submission Handling**: Allows users to reply to an existing post. Replies can include text and an optional image.
- **Replies Display**: Retrieves and displays all replies to a particular post, maintaining chronological order.
- **HTML Form**: Includes an HTML form for replying to the original post with optional image upload functionality.

### 3. `style.css`
This file contains the CSS styles for the project.
- **Global Styling**: Sets the default font, background, and padding for the page.
- **Containers**: Defines styles for the main content container to constrain width and add padding for better readability.
- **Form Elements**: Styles the input fields, textareas, and submit buttons for a consistent appearance.
- **Posts and Replies**: Styles the appearance of posts and replies, including images, to ensure clear distinction between original posts and replies.
- **Error Messages**: Adds visual emphasis to error messages for better user experience.
- **Responsive Design**: Implements media queries for mobile responsiveness to adjust fonts, container widths, and element sizes on smaller screens.

## Setting Up the Project
### Requirements
- **PHP**: Version 8.4.1.
- **SQLite3**: For managing the database (`database.db`).
- **Web Server**: Apache, Nginx, or another PHP-compatible server.

### Installation Steps
1. **Clone the Repository**
   ```sh
   git clone https://github.com/yourusername/discussion-board.git
   cd discussion-board
   ```

2. **Create Upload Directory**
   Ensure that the `uploads` directory is present in the root directory for storing user-uploaded images.
   ```sh
   mkdir uploads
   chmod 777 uploads
   ```

3. **Database Initialization**
   When you load `index.php` for the first time in your browser, the script will automatically create `database.db` and initialize the necessary tables.

4. **Run the Project**
   You can run the project on a local PHP server:
   ```sh
   php -S localhost:8000
   ```
   Then visit `http://localhost:8000/index.php` in your browser.

### Directory Structure
```
discussion-board/
|-- index.php           # Main page for viewing and creating posts
|-- reply.php           # Page for viewing and replying to specific posts
|-- style.css           # Styling for the discussion board
|-- database.db         # SQLite3 database (auto-created when the application runs)
|-- uploads/            # Directory for storing uploaded images
|-- fade.png            # Optional background image for styling
```

## Usage Instructions
1. **Creating a New Post**: Navigate to the main board (`index.php`). Enter your name (maximum 14 characters), type your post (up to 14,000 characters), and optionally upload an image (JPG, PNG, GIF). Click "Post" to submit.
2. **Viewing and Replying to a Post**: Click "Reply" on a post to view the post and its replies. On the reply page, you can enter your reply details and optionally upload an image.
3. **Pagination**: Use the pagination links at the bottom of the main page to navigate through different pages of posts.

## Key Design Decisions
- **SQLite3 Database**: Chosen for simplicity in managing data storage without needing an external database server.
- **Input Sanitization**: All input fields are sanitized using `htmlspecialchars()` to prevent cross-site scripting (XSS) attacks. Adjusted to use `ENT_QUOTES | ENT_HTML5` to meet PHP 8.4.1 standards.
- **Image Uploads**: Only `JPG`, `PNG`, and `GIF` formats are allowed for security reasons. Files are saved with unique names using `uniqid()`.
- **Pagination**: Pagination helps in breaking down large numbers of posts for better performance and user experience.
- **Responsive Layout**: Uses CSS media queries to ensure the interface looks good on both desktops and mobile devices.

## Security Considerations
- **Sanitization**: Inputs are sanitized with `htmlspecialchars()` using `ENT_QUOTES | ENT_HTML5` for compatibility with PHP 8.4.1 to prevent XSS attacks.
- **File Uploads**: Only specific image formats are allowed, and uploaded images are given unique names to avoid overwriting.
- **Directory Permissions**: The `uploads` directory must be writable by the server, but care should be taken to set appropriate permissions (`chmod 777`) only where necessary.

## Future Improvements
- **User Authentication**: Add support for user registration and authentication to track users and improve security.
- **Editing and Deleting Posts**: Allow users to edit or delete their own posts and replies.
- **Image Compression**: Implement automatic compression for uploaded images to save disk space.
- **Database Optimization**: As the number of posts grows, indexing and optimization of queries might be necessary to maintain performance.
- **Rich Text Editing**: Integrate a rich text editor (e.g., CKEditor) for enhanced user experience when composing posts.

## License
This project is open source and available under the MIT License. Feel free to modify and distribute as per the license conditions.

## Contributing
Contributions are welcome! Please feel free to submit a Pull Request or open an Issue if you encounter any bugs or have suggestions for improvements.

## Contact
For any questions or support, please email `yourname@example.com` or create an issue on the repository.

---
Thank you for using and contributing to this project! We hope you enjoy building and expanding this simple discussion board.

